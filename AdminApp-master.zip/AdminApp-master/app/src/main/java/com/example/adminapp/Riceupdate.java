package com.example.adminapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Riceupdate extends AppCompatActivity {

    DatabaseReference db;
    EditText editnum;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_riceupdate);
        editnum=(EditText)findViewById(R.id.editText3);

    }

    public void onTouch2(View view)
    {
        String dat=editnum.getText().toString();
        String loginid=getIntent().getStringExtra("login_id");
        db= FirebaseDatabase.getInstance().getReference(loginid);
        db.child("ricesack_space").setValue(dat);
        Toast.makeText(this, "updated", Toast.LENGTH_SHORT).show();

    }
}
