package com.example.adminapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class HomeActivity extends AppCompatActivity {

    FirebaseDatabase database;
    DatabaseReference myRef;
    private Button addButton;
    private EditText enterText;
    private TextView displayText;
    String currText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        addButton = (Button) findViewById(R.id.addButton);
        enterText = (EditText) findViewById(R.id.entertext);
        displayText = (TextView) findViewById(R.id.displaytext);

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              /*  database = FirebaseDatabase.getInstance();
                myRef = database.getReference("ricepack");

                currText = enterText.getText().toString();
                myRef.setValue(currText);  */
                onRetrieveData();
            }
        });


    }

    public void onRetrieveData(){
      /*  myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
             //   String value = dataSnapshot.getValue(String.class);
              //  displayText.setText("Value : "+value);
                Intent intu=new Intent(HomeActivity.this,Listout.class);
                startActivity(intu);

            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Toast.makeText(getApplicationContext(),"Error in database",Toast.LENGTH_SHORT).show();
            }
        });  */
        Intent intu=new Intent(HomeActivity.this,Listout.class);
        currText = enterText.getText().toString();
        int n= Integer.parseInt(currText);
        intu.putExtra("riceval",n);
        startActivity(intu);
    }
}
