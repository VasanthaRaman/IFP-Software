package com.example.adminapp;

public class FBdata {

     public   String latitude;
     public String longitude;
      public  String ricesack_space;
     public  String shortest_dist;

     public String showDist()
     {
         return shortest_dist;
     }

}
