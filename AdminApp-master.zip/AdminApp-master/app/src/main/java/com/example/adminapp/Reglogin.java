package com.example.adminapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Reglogin extends AppCompatActivity {


    Button reg,loginn;TextView t;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reglogin);
       t = (TextView)findViewById(R.id.textView) ;
        reg=(Button) findViewById(R.id.reggg);
        loginn=(Button) findViewById(R.id.loginn);

    }

    public void regg(View view)
    {
        Intent intt = new Intent(this,LoginActivity.class);
        startActivity(intt);
    }

    public void loggin(View view)
    {
        Intent intt = new Intent(this,HomeActivity.class);
        startActivity(intt);
    }
}



