package com.example.adminapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;

public class Chk extends AppCompatActivity {

    TextView txtv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chk);
        txtv=(TextView)findViewById(R.id.textView7);
        DatabaseReference rootRef= FirebaseDatabase.getInstance().getReference();
        rootRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                for (DataSnapshot postSnapshot : snapshot.getChildren()) {
                    FBdata climate = postSnapshot.getValue(FBdata.class);
                    Toast.makeText(Chk.this, climate.ricesack_space, Toast.LENGTH_SHORT).show();
                    txtv.setText (climate.ricesack_space);


                }
            }

            @Override
            public void onCancelled(DatabaseError firebaseError) {
                /*
                 * You may print the error message.
                 **/

                Toast.makeText(Chk.this, "bla", Toast.LENGTH_SHORT).show();
            }
        });
    }
}