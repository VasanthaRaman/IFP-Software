package com.example.adminapp;

import androidx.appcompat.app.AppCompatActivity;


import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import android.app.Activity;
import android.content.Intent;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.maps.SupportMapFragment;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import java.io.InputStream;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Locale;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import static android.location.Location.distanceBetween;

public class MapsActivity extends AppCompatActivity implements OnMapReadyCallback {

    GoogleMap map;
    boolean mapReady = false;
    Geocoder geo;
    LatLng currLocation;
    Button saveButton ;
    FirebaseDatabase database;
    DatabaseReference myRef,db,db2;
    String email,pass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);

        //add code for selecting the location

        saveButton = (Button) findViewById(R.id.button);
        String loginid=getIntent().getStringExtra("login_id");
         email=getIntent().getStringExtra("email");
         pass=getIntent().getStringExtra("pass");
        Toast.makeText(this, loginid, Toast.LENGTH_SHORT).show();
        db= FirebaseDatabase.getInstance().getReference(loginid);

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              //  database = FirebaseDatabase.getInstance("");
              //  myRef = database.getReference("latitude");


                LatLng fixedloc= new LatLng(12.7509,80.1973);
                String latitude = String.valueOf(currLocation.latitude);
                String longitude = String.valueOf(currLocation.longitude);

               // myRef.setValue(latitude);
                db.child("latitude").setValue(latitude);
              //  myRef = database.getReference("longitude");
               // myRef.setValue(longitude);
                db.child("longitude").setValue(longitude);

                float sd=distanceBetween(fixedloc,currLocation);
                double dist = CalculationByDistance(fixedloc.latitude,fixedloc.longitude,currLocation.latitude,currLocation.longitude);
            //    myRef = database.getReference("short_Dist");
             //   myRef.setValue(String.valueOf(dist));
             //   myRef = database.getReference("sd");
             //   myRef.setValue(String.valueOf(sd));numberFormat.format(number
                 db.child("shortest_dist").setValue(numberFormat.format(dist));
                //set email and pass
                db.child("email").setValue(email);
                db.child("pass").setValue(pass);

              //double distance = google.map.geometry.spherical.computeDistanceBetween(new google.maps.LatLng(latitude1, longitude1), new google.maps.LatLng(latitude2, longitude2));
               // Intent intent = new Intent(MapsActivity.this,HomeActivity.class);
                //startActivity(intent);
                Toast.makeText(MapsActivity.this, "New PDS added!", Toast.LENGTH_SHORT).show();
               try{ wait(100); }
               catch (Exception e){ System.out.println(e); }
                finish();

            }
        });

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

   /* public String getDistance(double lat1, double lon1, double lat2, double lon2) {
        String distance = "";
        System.out.println(lat1+" "+lon1+" "+lat2+" "+lon2);
        String url = "http://maps.google.com/maps/api/directions/xml?origin=" + lat1 + "," + lon1 + "&destination=" + lat2 + "," + lon2 + "&sensor=false&units=metric";
        String tag[] = {"text"};  //will give distance as string e.g 1.2 km
// or tag[] = {"value"} if you want to get distance in metre e.g. 1234

        HttpResponse response = null;
        try {
            HttpClient httpClient = new DefaultHttpClient();
            HttpContext localContext = new BasicHttpContext();
            HttpPost httpPost = new HttpPost(url);
            response = httpClient.execute(httpPost, localContext);
            InputStream is = response.getEntity().getContent();
            DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            Document doc = builder.parse(is);
            if (doc != null) {
                NodeList nl;
                ArrayList args = new ArrayList();
                for (String s : tag) {
                    nl = doc.getElementsByTagName(s);
                    if (nl.getLength() > 0) {
                        Node node = nl.item(nl.getLength() - 1);
                        args.add(node.getTextContent());
                    } else {
                        args.add(" - ");
                    }
                }
                distance = String.format("%s", args.get(0));
            }
            else
            {
                System.out.print("Doc is null");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return distance;
    }

      */
   DecimalFormat numberFormat = new DecimalFormat("#.000");
    // System.out.println(numberFormat.format(number));
       private float distanceBetween(LatLng latLng1, LatLng latLng2) {
        Location loc1 = new Location(LocationManager.GPS_PROVIDER);
        Location loc2 = new Location(LocationManager.GPS_PROVIDER);
        loc1.setLatitude(latLng1.latitude);
        loc1.setLongitude(latLng1.longitude);
        loc2.setLatitude(latLng2.latitude);
        loc2.setLongitude(latLng2.longitude);
        return loc1.distanceTo(loc2);
    }
    public double CalculationByDistance(double initialLat, double initialLong,
                                        double finalLat, double finalLong){
        int R = 6371; // km (Earth radius)
        double dLat = toRadians(finalLat-initialLat);
        double dLon = toRadians(finalLong-initialLong);
        initialLat = toRadians(initialLat);
        finalLat = toRadians(finalLat);

        double a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                Math.sin(dLon/2) * Math.sin(dLon/2) * Math.cos(initialLat) * Math.cos(finalLat);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
        return R * c;
    }

    public double toRadians(double deg) {
        return deg * (Math.PI/180);
    }

    public void onMapReady(GoogleMap googleMap) {
        // Add a marker in Sydney, Australia,
        // and move the map's camera to the same location.


        map = googleMap;
        mapReady = true;
        LatLng chennai = new LatLng(13.0827,80.2707);
        CameraPosition cp = new CameraPosition.Builder().target(new LatLng(12.751451, 80.197442)).bearing(0).tilt(40).zoom(16).build();
        map.moveCamera(CameraUpdateFactory.newCameraPosition(cp));

        map.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
            @Override
            public void onMapClick(LatLng latLng) {
                MarkerOptions markerOptions = new MarkerOptions();
                markerOptions.position(latLng);
                markerOptions.title(latLng.latitude + " : " + latLng.longitude);
                currLocation = latLng;
                map.clear();
                map.animateCamera(CameraUpdateFactory.newLatLng(latLng));
                map.addMarker(markerOptions);

//                Toast.makeText(MapsActivity.this,"onMapClick:\n" + latLng.latitude + " : " +
//                        latLng.longitude,Toast.LENGTH_LONG).show();
            }
        });
//        map.addMarker(new MarkerOptions().position(new LatLng(12.751416, 80.197271)).title("CSE").icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ORANGE)));
//        map.addMarker(new MarkerOptions().position(new LatLng(12.751385, 80.197056)).title("IT").icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ORANGE)));
//        map.addMarker(new MarkerOptions().position(new LatLng(12.750751, 80.196232)).title("ECE").icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ORANGE)));
    }


}
