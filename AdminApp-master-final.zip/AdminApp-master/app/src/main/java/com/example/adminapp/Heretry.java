package com.example.adminapp;

import androidx.appcompat.app.AppCompatActivity;
import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.here.android.mpa.common.GeoCoordinate;
import com.here.android.mpa.common.OnEngineInitListener;
import com.here.android.mpa.mapping.Map;
import com.here.android.mpa.mapping.AndroidXMapFragment;

import com.here.android.mpa.mapping.MapFragment;
import com.here.android.mpa.mapping.MapMarker;
import com.here.android.mpa.mapping.MapObject;
import com.here.android.mpa.mapping.MapRoute;
import com.here.android.mpa.routing.RouteManager;
import com.here.android.mpa.routing.RouteOptions;
import com.here.android.mpa.routing.RoutePlan;
import com.here.android.mpa.routing.RouteResult;

import androidx.fragment.app.FragmentActivity;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class Heretry  extends FragmentActivity {

    // map embedded in the map fragment
    private Map map = null;

    // map fragment embedded in this activity
    private AndroidXMapFragment mapFragment = null;
    int x=0; public MapMarker prev;
    public ArrayList<MapObject> lis;
    GeoCoordinate curloc1,curloc2;
    //curloc1= new GeoCoordinate(lat1,lng1);
    double lat1,lng1;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        lat1=getIntent().getExtras().getDouble("lat1");
        lng1=getIntent().getExtras().getDouble("lng1");
        Toast.makeText(this, Double.toString(lat1), Toast.LENGTH_SHORT).show();
        curloc2= new GeoCoordinate(lat1,lng1);
        curloc1= new GeoCoordinate(12.751451, 80.197442, 0.0);
        initialize();
    }

    private void initialize() {
        setContentView(R.layout.activity_heretry);

        // Search for the map fragment to finish setup by calling init().
        mapFragment = (AndroidXMapFragment) getSupportFragmentManager().findFragmentById(R.id.mapfragment);

        // Set up disk cache path for the map service for this application
        // It is recommended to use a path under your application folder for storing the disk cache
//        boolean success = com.here.android.mpa.common.MapSettings.setIsolatedDiskCacheRootPath(
//                getApplicationContext().getExternalFilesDir(null) + File.separator + ".here-maps",
//                "blaintent"); /* ATTENTION! Do not forget to update {YOUR_INTENT_NAME} */
//
//        if (!success) {
//            Toast.makeText(getApplicationContext(), "Unable to set isolated disk cache path.", Toast.LENGTH_LONG);
//        } else
            {
            mapFragment.init(new OnEngineInitListener() {
                @Override
                public void onEngineInitializationCompleted(OnEngineInitListener.Error error) {
                    if (error == OnEngineInitListener.Error.NONE) {
                        // retrieve a reference of the map from the map fragment
                        map = mapFragment.getMap();
                        // Set the map center to the Vancouver region (no animation)
                        map.setCenter(new GeoCoordinate(12.751451, 80.197442, 0.0),
                                Map.Animation.NONE);
                        // Set the zoom level to the average between min and max
                        map.setZoomLevel((map.getMaxZoomLevel() + map.getMinZoomLevel()) / 2);
                        MapMarker defaultMarker2 = new MapMarker();
                        defaultMarker2.setCoordinate(curloc1);
                        map.addMapObject(defaultMarker2);

                        MapMarker defaultMarker3 = new MapMarker();
                        defaultMarker3.setCoordinate(curloc2);
                        map.addMapObject(defaultMarker3);

                        RouteManager rm = new RouteManager();
                        // Create the RoutePlan and add two waypoints
                        RoutePlan routePlan = new RoutePlan();
                        routePlan.addWaypoint(curloc1);
                        routePlan.addWaypoint(curloc2);
                        // Create the RouteOptions and set its transport mode & routing type
                        RouteOptions routeOptions = new RouteOptions();
                        routeOptions.setTransportMode(RouteOptions.TransportMode.CAR);
                        routeOptions.setRouteType(RouteOptions.Type.FASTEST);

                        routePlan.setRouteOptions(routeOptions);


                        // Calculate the route
                        rm.calculateRoute(routePlan, new RouteManager.Listener()
                        {
                            public void onProgress(int percentage) {
                                // Display a message indicating calculation progress
                            }

                            // Method defined in Listener
                            public void onCalculateRouteFinished(RouteManager.Error error, List<RouteResult> routeResult) {
                                // If the route was calculated successfully
                                if (error == RouteManager.Error.NONE) {
                                    // Render the route on the map
                                    MapRoute mapRoute = new MapRoute(routeResult.get(0).getRoute());
                                    map.addMapObject(mapRoute);
                                }
                                else {
                                    // Display a message indicating route calculation failure
                                    Toast.makeText(Heretry.this, "Errrr", Toast.LENGTH_SHORT).show();
                                    Log.e("errr","its error");
                                }
                            }
                        });

                    }


             else {
                        System.out.println("ERROR: Cannot initialize Map Fragment");
                    }
                }
            });
        }
    }
}