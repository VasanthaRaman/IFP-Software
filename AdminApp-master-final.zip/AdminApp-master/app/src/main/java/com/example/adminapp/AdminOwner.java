package com.example.adminapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class AdminOwner extends AppCompatActivity {

    Button b1,b2,bb3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_owner);
        b1=(Button) findViewById(R.id.button2);
        b2=(Button) findViewById(R.id.button3);
      //  bb3=(Button) findViewById(R.id.bb3);
    }

    public void logingd(View view)
    {
        Intent intr= new Intent(this,Gdmlogin.class);
        startActivity(intr);
    }

    public void loginpds(View view)
    {
        Intent intr= new Intent(this,Pdsologin.class);
        startActivity(intr);
    }

//    public void callhere(View view)
//    {
//        Intent intr= new Intent(this,Heretry.class);
//        double lat1=  12.8793;
//        double lat2= 80.0819;
//        intr.putExtra("lat1",lat1);
//        intr.putExtra("lng1",lat2);
//        startActivity(intr);
//    }
}
