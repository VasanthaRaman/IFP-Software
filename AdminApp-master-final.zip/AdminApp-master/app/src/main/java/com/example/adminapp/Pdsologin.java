package com.example.adminapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class Pdsologin extends AppCompatActivity {

    Button button1;
    EditText edittext;
    EditText editpass;
    public long child_count;
    int n;         int hk=-1,found=0;
    ArrayList<String> arrl;
    ArrayList<Map> arrc;
    ArrayList<String> ftf;
    ArrayList<String> arrsd;
    ArrayList<String> arremail;
    ArrayList<String> arrpass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pdsologin);
        edittext=(EditText)findViewById(R.id.editText);
        button1=(Button)findViewById(R.id.button);
        editpass=(EditText)findViewById(R.id.passtext1);
    }

    public void oncliq(View view)
    {
        String user=edittext.getText().toString();
        String passw=editpass.getText().toString();
        String str="";
        Intent iint=new Intent(this,Riceupdate.class);
        for(int i=0;i<user.length();i++)
        {
            if(user.charAt(i)=='@')
                break;
            else
                str+=user.charAt(i);
        }

        iint.putExtra("login_id", str);
        //if(authenticate)
        startActivity(iint);
    }

    DatabaseReference myRef=FirebaseDatabase.getInstance().getReference("pds_info");

    public int authenticate(final String user, final String passw){

  myRef.addValueEventListener(new ValueEventListener() {
        @Override

        public void onDataChange(DataSnapshot dataSnapshot) {
            child_count = dataSnapshot.getChildrenCount();
            arrl=new ArrayList<String>();
            ftf=new ArrayList<>();
            arrsd=new ArrayList<>();
            int k=0;
            arrc=new ArrayList<>();
            arremail=new ArrayList<>();
            arrpass=new ArrayList<>();


            //Toast.makeText(Listout.this, Long.toString(child_count), Toast.LENGTH_SHORT).show();
            for (DataSnapshot postSnapshot: dataSnapshot.getChildren()) {
                Log.e("dddd",postSnapshot.getKey());
                Log.e("mmmm",postSnapshot.child("ricesack_space").getValue().toString());
                // FBdata fbb= postSnapshot.getValue(FBdata.class);
                Map<String, Object> td = (HashMap<String,Object>) postSnapshot.getValue();
                List<Object> values = new ArrayList<Object>(td.values());

                arrl.add(postSnapshot.getKey());
                ftf.add(postSnapshot.child("ricesack_space").getValue().toString());
                arrsd.add(postSnapshot.child("shortest_dist").getValue().toString());
                arremail.add(postSnapshot.child("email").getValue().toString());
                arrpass.add(postSnapshot.child("pass").getValue().toString());
                Toast.makeText(Pdsologin.this, postSnapshot.getValue().toString(), Toast.LENGTH_SHORT).show();
                //   Log.e("ffff",fbb.shortest_dist.toString());
                Log.e("rice sack space",values.get(1).toString());
                Log.e("shortest dist",values.get(2).toString());
                Log.e("emailid",values.get(3).toString());
                Log.e("passss",values.get(4).toString());
                Log.e("combany",td.toString());

                arrc.add(td);
            }
//            for(int i=0;i<arrsd.size()-1;i++)
//            {
//                for(int j=0;j<arrsd.size()-i-1;j++)
//                {
//                    double ii=Double.parseDouble(arrsd.get(j)); double jj=Double.parseDouble(arrsd.get(j+1));
//                    if(ii>jj)
//                    {
//                        String temp1= arrsd.get(j);
//                        arrsd.set(j,arrsd.get(j+1));
//                        arrsd.set(j+1,temp1);
//
//                        String temp2= arrl.get(j);
//                        arrl.set(j,arrl.get(j+1));
//                        arrl.set(j+1,temp2);
//
//                        String temp3= ftf.get(j);
//                        ftf.set(j,ftf.get(j+1));
//                        ftf.set(j+1,temp3);
//
//                    }
//                }
//            }
           // init();
            for(int i=0;i<arremail.size();i++)
            {
                if(arremail.get(i).equals(user) && arremail.get(i).equals(passw))
                {
                    hk=i; found=1;
                    break;
                }
            }

        }

        @Override
        public void onCancelled(DatabaseError databaseError) {
            // Getting Post failed, log a message
            // Log.w(TAG, "loadPost:onCancelled", databaseError.toException());
            // ...
            Toast.makeText(Pdsologin.this, "failed to fetch", Toast.LENGTH_SHORT).show();
        }
    });
  if(found==1)
      return hk;
  else
      return -1;
}


}
