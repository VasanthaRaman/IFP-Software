package com.example.adminapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.FirebaseAuth;


public class Gdmlogin extends AppCompatActivity {

    private static FirebaseAuth mAuth;
    Button b1;
    EditText e1, p1;
    String email, password;
    String orgemail="gdmanager@gmail.com";
    String orgpass="12345678";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gdmlogin);
        b1 = (Button) findViewById(R.id.button4);
        e1 = (EditText) findViewById(R.id.emailtext);
        p1 = (EditText) findViewById(R.id.passtext);

        // Configure sign-in to request the user's ID, email address, and basic
// profile. ID and basic profile are included in DEFAULT_SIGN_IN.
//        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
//                .requestEmail()
//                .build();

        // Build a GoogleSignInClient with the options specified by gso.
//        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);
    }

    public void onClickk(View view) {

        email = e1.getText().toString();
        password = p1.getText().toString();

      /*  mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {

                        if (task.isSuccessful()) {

                            //Login Successful

                            FirebaseUser user = mAuth.getCurrentUser();
                            Intent intent = new Intent(Gdmlogin.this, Reglogin.class);
                            startActivity(intent);
                        } else {
                            Toast.makeText(Gdmlogin.this, "Login failed .Please try again!", Toast.LENGTH_SHORT).show();
                           // onSignIn(email, password);
                        }
                    }
                });

    }

    public void onSignIn(String email, String password) {

        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {

                        if (task.isSuccessful()) {
                            FirebaseUser user = mAuth.getCurrentUser();
                            Intent intent = new Intent(Gdmlogin.this, MapsActivity.class);
                            startActivity(intent);
                        } else {
                            Toast.makeText(Gdmlogin.this, "Login failed .Please try again!", Toast.LENGTH_SHORT).show();
                        }
                    }
                }); */
        if(email.equals(orgemail) && password.equals(orgpass)) {
            Intent intent = new Intent(Gdmlogin.this, Reglogin.class);
            startActivity(intent);
        }
        else
        {
            Toast.makeText(this, "Enter correct username and password", Toast.LENGTH_SHORT).show();
        }
    }
}
