package com.example.adminapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RiceListout extends AppCompatActivity {

    public long child_count;
   int nn; TextView tt; String ss=" ";
    ArrayList<String> arrl;
    ArrayList<Map> arrc;
    ArrayList<String> ftf;
    ArrayList<String> arrsd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rice_listout);
        onRetrieveData();
    }

    DatabaseReference myRef = FirebaseDatabase.getInstance().getReference("sack_details");

    public void onRetrieveData() {
        myRef.addValueEventListener(new ValueEventListener() {
            @Override

            public void onDataChange(DataSnapshot dataSnapshot) {
                child_count = dataSnapshot.getChildrenCount();
                arrl = new ArrayList<String>();
                ftf = new ArrayList<>();
                arrsd = new ArrayList<>();
                int k = 0;
                arrc = new ArrayList<>();
                if(child_count>0) {
                    Toast.makeText(RiceListout.this, Long.toString(child_count), Toast.LENGTH_SHORT).show();
                    for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                        Log.e("dddd", postSnapshot.getKey());
                        Log.e("mmmm", postSnapshot.child("temperature").getValue().toString());
                        nn = Integer.parseInt(Long.toString(child_count));
                        Log.e("childcount", Long.toString(child_count));

                        // FBdata fbb= postSnapshot.getValue(FBdata.class);
                        Map<String, Object> td = (HashMap<String, Object>) postSnapshot.getValue();
                        List<Object> values = new ArrayList<Object>(td.values());

                        arrl.add(postSnapshot.getKey()); ss=postSnapshot.getKey();
                        ftf.add(postSnapshot.child("moisture").getValue().toString());
                        arrsd.add(postSnapshot.child("temperature").getValue().toString());
                        Toast.makeText(RiceListout.this, postSnapshot.getValue().toString(), Toast.LENGTH_SHORT).show();
                        //   Log.e("ffff",fbb.shortest_dist.toString());
                        Log.e("ricesackspace", values.get(0).toString());
                        Log.e("shortestdist", values.get(1).toString());
                        Log.e("combany", td.toString());
                        arrc.add(td);
                    }
                }
                else
                {
                    tt=(TextView)findViewById(R.id.textView6);
                    tt.setText("No rice needs to be transported");
                }
                init();


            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e("cancelled","err");
            }
        });

    }

    public void init() {
        Toast.makeText(this, "childcount="+Long.toString(nn), Toast.LENGTH_SHORT).show();
        Log.e("childcount2",Long.toString(child_count));
        TableLayout stk = (TableLayout) findViewById(R.id.table_main);
        TableRow tbrow0 = new TableRow(this);
        TextView tv0 = new TextView(this);
        tv0.setText(" Sl.No ");
        tv0.setTextColor(Color.WHITE);
        tbrow0.addView(tv0);
        TextView tv1 = new TextView(this);
        tv1.setText(" Scan code ");
        tv1.setTextColor(Color.WHITE);
        tbrow0.addView(tv1);
        TextView tv2 = new TextView(this);
        tv2.setText(" Moisture ");
        tv2.setTextColor(Color.WHITE);
        tbrow0.addView(tv2);
        TextView tv3 = new TextView(this);
        tv3.setText(" Temperature ");
        tv3.setTextColor(Color.WHITE);
        tbrow0.addView(tv3);
        stk.addView(tbrow0);
        int lm=11;
        Log.e("childcount3",Long.toString(nn));
        for (int i = 0; i < nn; i++) {
            TableRow tbrow = new TableRow(this); tbrow.setId(i+4);
            TextView t1v = new TextView(this);
            t1v.setText("" + (i+1)); t1v.setId(lm*(i+1));
            t1v.setTextColor(Color.WHITE);
            t1v.setGravity(Gravity.CENTER);
            tbrow.addView(t1v);
            TextView t2v = new TextView(this);
            t2v.setText(arrl.get(i)); t1v.setId(lm*(i+1));
            t2v.setTextColor(Color.WHITE);
           t2v.setGravity(Gravity.CENTER);
            tbrow.addView(t2v);
            TextView t3v = new TextView(this);
            t3v.setText(ftf.get(i)); t1v.setId(lm*(i+1));
            t3v.setTextColor(Color.WHITE);
           t3v.setGravity(Gravity.CENTER);
            tbrow.addView(t3v);
            TextView t4v = new TextView(this);
           t4v.setText(arrsd.get(i));  t1v.setId(lm*(i+1));
            t4v.setTextColor(Color.WHITE);
            t4v.setGravity(Gravity.CENTER);
            tbrow.addView(t4v);
            tbrow.setBackgroundColor(Color.RED);
            stk.addView(tbrow);
        }
        tt=(TextView)findViewById(R.id.textView6);
        tt.setText(tt.getText().toString()+nn);
//        int m=n,kk=0,pp=0;
//        for(int i=0;i<ftf.size();i++)
//        {
//            pp+=Integer.parseInt(ftf.get(i));
//        }
//        if(m>pp)
//        {   m=m-pp;
//            Toast.makeText(this, "You have an excess of "+m+" ricesacks", Toast.LENGTH_SHORT).show();
//            for(int i=0;i<ftf.size();i++)
//            {
//                TableRow tvv = (TableRow) findViewById(i + 4);
//                tvv.setBackgroundColor(Color.GREEN);
//            }
//        }
//        else {
//            while (m > 0) {
//                m = m - Integer.parseInt(ftf.get(kk++));
//            }
//            for (int i = 0; i < kk; i++) {
//                //make kk no.of rows green..
//                TableRow tvv = (TableRow) findViewById(i + 4);
//                tvv.setBackgroundColor(Color.GREEN);
//            }
//        }
    }

    public void switchTo(View view)
    {


        Intent intent = new Intent(RiceListout.this,HomeActivity.class);
        intent.putExtra("defaultval",nn);
        startActivity(intent);
    }
}
